FlashGrab (a.k.a. lexml2anki, SyncFromXml, etc.)
==========

An Anki addon for pulling flashcard data (one-way sync) from XML. Optimized for LIFT XML (from WeSay or FLEx).
See the Anki website's list of provided addons.
https://ankiweb.net/shared/info/915685712

..