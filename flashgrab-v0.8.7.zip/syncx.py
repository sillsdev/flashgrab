"""
Anki addon that performs a one-way sync, pulling data into Anki 
from the source XML file(s) as specified in the config file.
"""

from syncxml import SyncFromXML

